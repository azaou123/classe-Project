#include"classe.h"


int main()
{
    genere();
    Etudiant tableau[15];
    printf("Affichage a partir de fichier : \n");
    affFile();
    fileToArray(tableau);
    printf("Affichage a partir de tableau : \n");
    affTab(tableau);
    trieTab(tableau);
    printf("Voici le tableau apres le trie selon le nom : \n");
    affTab(tableau);
    ajouToFile();
    fileToArray(tableau);
    printf("Affichage a partir de fichier : \n");
    affFile();
    printf("Affichage a partir de tableau : \n");
    affTab(tableau);
    trieTab(tableau);
    printf("Voici le tableau apres le trie selon le nom : \n");
    affTab(tableau);
    printf("Voici les moyennes de votre classe dans l ordre de trie : \n");
    for (k=0;k<nbrEtuds;k++){
        printf("%.2f\t",moyEtudiant(tableau[k]));
    }
    printf("\n");
    printf("Le majornat de votre classe est : \n");
    affEtudiant(tableau[majorant(tableau)]);
    printf("Le minorant de votre classe est : \n");
    affEtudiant(tableau[minorant(tableau)]);
    printf("Maintenant on va creer le fichier resultatClasse de votre classe .\n");
    trieNotes(tableau);
    affTab(tableau);
    results(tableau);
    return 0;
}
