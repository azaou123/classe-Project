#include"classe.h"

//Fonction d Remplissage de fichier
void genere(void){
    Etudiant eleve ;
    printf("Entrer le nombre initiale de votre etudiants : ");
    do {scanf("%d",&nbrEtuds);}while (nbrEtuds>MAX);
    FILE *ptr = fopen("classe.txt","w");
    for (i=0;i<nbrEtuds;i++){
        printf("Saisie de L etudiant : \n");
        printf("Nom & Prenom : ");scanf("%s %s",eleve.nom,eleve.prenom);
        printf("Numero : ");scanf("%d",&eleve.numero);
        printf("Les notes : ");scanf("%f %f %f",&eleve.notes[0],&eleve.notes[1],&eleve.notes[2]);
        fprintf(ptr,"%s %s %d\t\t%.2f %.2f %.2f\n",eleve.nom,eleve.prenom,eleve.numero,eleve.notes[0],eleve.notes[1],eleve.notes[2]);
    }
    fclose(ptr);
}

//Fonction de transformation du fichier au tableau
void fileToArray(Etudiant *tab ){
    i=0 ;
    FILE *ptr = fopen("classe.txt","r");
    while(!feof(ptr)){
        fscanf(ptr,"%s %s %d\t\t%f %f %f\n",(tab+i)->nom,(tab+i)->prenom,&(tab+i)->numero,&(tab+i)->notes[0],&(tab+i)->notes[1],&(tab+i)->notes[2]);
        i++;
    }
    fclose(ptr);
}

//Affichage de contenu de fichier
void affFile(void){
    Etudiant eleve ;
    FILE *ptr = fopen("classe.txt","r");
    while(!feof(ptr)){
        fscanf(ptr,"%s %s %d\t\t%f %f %f\n",eleve.nom,eleve.prenom,&eleve.numero,&eleve.notes[0],&eleve.notes[1],&eleve.notes[2]);
        printf("%s %s %d\t\t%.2f %.2f %.2f\n",eleve.nom,eleve.prenom,eleve.numero,eleve.notes[0],eleve.notes[1],eleve.notes[2]);
    }
    fclose(ptr);
}

//Fonction qui affiche un etudiant :
void affEtudiant (Etudiant eleve){
    printf("%s %s %d\t\t%.2f %.2f %.2f\n",eleve.nom,eleve.prenom,eleve.numero,eleve.notes[0],eleve.notes[1],eleve.notes[2]);
}

//Fonction de affichage de tableau
void affTab(Etudiant *tab){
    for (i=0;i<nbrEtuds;i++){
        affEtudiant(tab[i]);
    }
}

//Fonction de permutation de deux Etudiants
void permute(Etudiant *a, Etudiant *b){
    char chaine[10];
    strcpy(chaine,a->nom);strcpy(a->nom,b->nom);strcpy(b->nom,chaine);
    strcpy(chaine,a->prenom);strcpy(a->prenom,b->prenom);strcpy(b->prenom,chaine);
    a->numero=a->numero+b->numero;b->numero=a->numero-b->numero;a->numero=a->numero-b->numero;
    a->notes[0]=a->notes[0]+b->notes[0];b->notes[0]=a->notes[0]-b->notes[0];a->notes[0]=a->notes[0]-b->notes[0];
    a->notes[1]=a->notes[1]+b->notes[1];b->notes[1]=a->notes[1]-b->notes[1];a->notes[1]=a->notes[1]-b->notes[1];
    a->notes[2]=a->notes[2]+b->notes[2];b->notes[2]=a->notes[2]-b->notes[2];a->notes[2]=a->notes[2]-b->notes[2];
}

//Fonction de trie de tableau
void trieTab (Etudiant *tab){
    for (i=0 ; i<nbrEtuds ;i++){
        for (j=i ; j<nbrEtuds;j++){
            if (strcmp((tab+i)->nom,(tab+j)->nom)>0)permute(&tab[j],&tab[i]);
        }
    }
}

//Ajout d'autres elements au fichiers
void ajouToFile (void ){
    Etudiant eleve ;
    printf("Combien de elements voulez vous ajouter : ");scanf("%d",&n);
    nbrEtuds+=n;
    FILE *ptr = fopen("classe.txt","a");
    for (i=0;i<n;i++){
        printf("Saisie de L etudiant : \n");
        printf("Nom & Prenom : ");scanf("%s %s",eleve.nom,eleve.prenom);
        printf("Numero : ");scanf("%d",&eleve.numero);
        printf("Les notes : ");scanf("%f %f %f",&eleve.notes[0],&eleve.notes[1],&eleve.notes[2]);
        fprintf(ptr,"%s %s %d\t\t%.2f %.2f %.2f\n",eleve.nom,eleve.prenom,eleve.numero,eleve.notes[0],eleve.notes[1],eleve.notes[2]);
    }
    fclose(ptr);
}

//Fonction Calculant le moyenne d un Etudiant donnee
float moyEtudiant (Etudiant eleve){
    return ((eleve.notes[0]+eleve.notes[1]+eleve.notes[2])/3);
}

//Fonction retournant Le majourant de Classe
int majorant (Etudiant *tab){
    int maj = 0 ;
    for (i=1;i<nbrEtuds;i++){
        if (moyEtudiant(tab[i])>moyEtudiant(tab[maj]))maj=i;
    }
    return maj ;
}

//Fonction retournant Le monorant de classe
int minorant (Etudiant *tab){
    int min = 0 ;
    for (i=1;i<nbrEtuds;i++){
        if (moyEtudiant(tab[i])<moyEtudiant(tab[min]))min=i;
    }
    return min ;
}

//Fonction qui trie selon la moyenne des notes
void trieNotes (Etudiant *tab){
    for (i=0 ; i<nbrEtuds ;i++){
        for (j=i ; j<nbrEtuds;j++){
            if (moyEtudiant(tab[j])>moyEtudiant(tab[i]))permute(&tab[j],&tab[i]);
        }
    }
}

//Fonction qui cree le fichier resultat des etudiants
void results(Etudiant *tab){
    FILE *ptr = fopen ("resultatClasse.txt","w");
    for(i=0;i<nbrEtuds;i++){
        fprintf(ptr,"%s %s : %.2f\n",tab[i].nom , tab[i].prenom,moyEtudiant(tab[i]));
    }
    fclose(ptr);
    printf("Le fichier reultat a ete cree avec succes .\n");
}



