#ifndef CLASSE_H_INCLUDED
#define CLASSE_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 15
int i , j , k ;
int n , m ;
int nbrEtuds ;

//Structure de controle de chaque etudiant
typedef struct{
    char nom[10],prenom[10];
    int numero ;
    float notes[3];
} Etudiant ;


//Les prototypes des fonctions
extern void genere(void);
extern void fileToArray(Etudiant * );
extern void affEtudiant(Etudiant);
extern void affFile(void);
extern void affTab(Etudiant *);
extern void permute(Etudiant *, Etudiant *);
extern void trieTab (Etudiant *);
extern void ajouToFile (void );
extern float moyEtudiant(Etudiant);
extern int majorant(Etudiant *tab);
extern int minorant(Etudiant *tab);
extern void trieNotes (Etudiant *);
extern  void results(Etudiant *tab);





#endif // CLASSE_H_INCLUDED
